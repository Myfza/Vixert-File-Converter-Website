# File Converter

Aplikasi ini adalah alat konversi file berbasis command-line yang mendukung konversi antara PDF, DOCX, dan gambar.

## Fitur

- Konversi PDF ke JPG/PNG
- Konversi PDF ke DOCX
- Konversi DOCX ke PDF
- Konversi JPG ke PNG dan sebaliknya

## Persyaratan

- Python 3.x
- Install dependensi dengan menjalankan: